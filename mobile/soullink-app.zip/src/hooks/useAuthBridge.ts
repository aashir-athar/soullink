// src/hooks/useAuthBridge.ts — wires Clerk's session token into the API client.
//
// FIX: Previously used useEffect to register the token getter, which ran AFTER
// the first render. Any API call made immediately on mount (e.g. photo upload
// on "Complete my profile") fired without a token → 401.
//
// Now we register the getter synchronously during render so it is available
// before any child component fires a request.

import { registerTokenGetter } from '@/src/services/api';
import { disconnectSocket } from '@/src/services/socket';
import { useAuth } from '@clerk/expo';
import { useEffect, useRef } from 'react';

export function useAuthBridge(): void {
  const { isSignedIn, getToken } = useAuth();

  // Keep a ref so the token getter closure always calls the latest getToken
  const getTokenRef = useRef(getToken);
  getTokenRef.current = getToken;

  // Register synchronously on every render (not in an effect) so the getter
  // is in place before any child component fires its first request.
  registerTokenGetter(async () => {
    try {
      return await getTokenRef.current();
    } catch {
      return null;
    }
  });

  useEffect(() => {
    if (!isSignedIn) {
      disconnectSocket();
    }
  }, [isSignedIn]);
}