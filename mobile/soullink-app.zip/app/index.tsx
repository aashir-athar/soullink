// app/index.tsx — Entry point router.
//
// Flow:
//   Not signed in                            → /welcome
//   Signed in, no profile (404)              → /(onboarding)/step-1
//   Signed in, profile exists, not approved  → /(verification)/selfie
//   Signed in, profile exists, approved      → /(tabs)

import { useAuth } from '@clerk/expo';
import { Redirect } from 'expo-router';
import React from 'react';

import { SoulLinkLoader } from '@/src/components/ui/SoulLinkLoader';
import { useTheme } from '@/src/contexts/ThemeContext';
import { useMyProfile } from '@/src/hooks/useApi';

export default function Index() {
  const { isLoaded, isSignedIn } = useAuth();
  const { theme } = useTheme();
  const { data: profile, isLoading: profileLoading } = useMyProfile(!!isSignedIn);

  // Wait for Clerk to initialise
  if (!isLoaded) {
    return <SoulLinkLoader />;
  }

  // Not signed in → welcome screen
  if (!isSignedIn) {
    return <Redirect href="/welcome" />;
  }

  // Signed in — wait for profile fetch to complete
  if (profileLoading) {
    return <SoulLinkLoader />;
  }

  // No profile found → onboarding
  if (!profile) {
    return <Redirect href="/(onboarding)/step-1" />;
  }

  // Profile exists but not verified → selfie screen
  if (profile.verificationStatus !== 'approved') {
    return <Redirect href="/(verification)/selfie" />;
  }

  // All good → main app
  return <Redirect href="/(tabs)" />;
}