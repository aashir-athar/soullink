// app/(auth)/sign-in.tsx — Email + password sign-in.

import { useSignIn } from '@clerk/expo';
import { type Href, useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';

import { Button } from '@/src/components/ui/Button';
import { Input } from '@/src/components/ui/Input';
import { SafeScreen } from '@/src/components/ui/SafeScreen';
import { ScreenHeader } from '@/src/components/ui/ScreenHeader';
import { Text } from '@/src/components/ui/Text';
import { haptics } from '@/src/utils/haptics';

export default function SignIn() {
  const router = useRouter();
  const { signIn, errors, fetchStatus } = useSignIn()

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSignIn = async () => {
    setError(null);
    setLoading(true);
    try {
      const attempt = await signIn.password({
        emailAddress: email,
        password: password,
      });
      if (signIn.status === 'complete') {
        await signIn.finalize({
          navigate: ({ session, decorateUrl }) => {
            if (session?.currentTask) {
              // Handle pending session tasks
              // See https://clerk.com/docs/guides/development/custom-flows/authentication/session-tasks
              console.log(session?.currentTask)
              return
            }

            const url = decorateUrl('/')
            if (url.startsWith('http')) {
              window.location.href = url
            } else {
              router.push(url as Href)
            }
          },
        });
        haptics.success();
        router.replace('/');
      }
      else if (signIn.status === 'needs_second_factor') {
        // See https://clerk.com/docs/guides/development/custom-flows/authentication/multi-factor-authentication
      } else if (signIn.status === 'needs_client_trust') {
        // For other second factor strategies,
        // see https://clerk.com/docs/guides/development/custom-flows/authentication/client-trust
        const emailCodeFactor = signIn.supportedSecondFactors.find(
          (factor) => factor.strategy === 'email_code',
        )

        if (emailCodeFactor) {
          await signIn.mfa.sendEmailCode()
        }
      }
      else {
        setError('Additional verification required.');
      }
    } catch (e) {
      const err = e as { errors?: { message?: string }[]; message?: string };
      setError(
        err.errors?.[0]?.message ?? err.message ?? 'Could not sign in.'
      );
      haptics.error();
    } finally {
      setLoading(false);
    }
  };

  const disabled = !email || !password;

  return (
    <SafeScreen keyboardAvoiding>
      <ScreenHeader title="Welcome back" />
      <ScrollView
        contentContainerStyle={{ paddingTop: 16, paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <Text variant="title1" style={{ marginBottom: 8 }}>
          Sign in
        </Text>
        <Text variant="body" tone="secondary" style={{ marginBottom: 28 }}>
          Your matches and messages are waiting.
        </Text>

        <View style={{ gap: 16 }}>
          <Input
            label="Email"
            value={email}
            onChangeText={setEmail}
            placeholder="you@example.com"
            keyboardType="email-address"
            autoCapitalize="none"
            autoComplete="email"
          />
          <Input
            label="Password"
            value={password}
            onChangeText={setPassword}
            placeholder="Your password"
            secureTextEntry
            autoComplete="password"
          />
        </View>

        {error ? (
          <Text variant="caption" tone="error" style={{ marginTop: 16 }}>
            {error}
          </Text>
        ) : null}

        <View style={{ marginTop: 28 }}>
          <Button
            label="Sign in"
            onPress={handleSignIn}
            loading={loading}
            disabled={disabled}
            fullWidth
          />
        </View>

        <Pressable
          onPress={() => router.replace('/(auth)/sign-up')}
          style={{ marginTop: 20, alignItems: 'center' }}
        >
          <Text variant="body" tone="secondary">
            New to Soullink?{' '}
            <Text variant="bodyMedium" tone="accent">
              Create account
            </Text>
          </Text>
        </Pressable>
      </ScrollView>
    </SafeScreen>
  );
}
