// app/(auth)/sign-up.tsx — Email + password sign-up (Clerk).
//
// The age gate itself happens at profile creation (server validates DOB).
// Here we just get the user into a Clerk session. We still require the
// explicit "I'm 18+" confirmation checkbox to set user expectations.

import { useAuth, useSignUp } from '@clerk/expo';
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';

import { Button } from '@/src/components/ui/Button';
import { Input } from '@/src/components/ui/Input';
import { SafeScreen } from '@/src/components/ui/SafeScreen';
import { ScreenHeader } from '@/src/components/ui/ScreenHeader';
import { Text } from '@/src/components/ui/Text';
import { useTheme } from '@/src/contexts/ThemeContext';
import { haptics } from '@/src/utils/haptics';
import { Ionicons } from '@expo/vector-icons';
import { Pressable } from 'react-native';

export default function SignUp() {
  const { theme } = useTheme();
  const router = useRouter();
  const { signUp, errors, fetchStatus } = useSignUp()
  const { isSignedIn } = useAuth()

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [ageOk, setAgeOk] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pendingCode, setPendingCode] = useState(false);
  const [code, setCode] = useState('');


  const handleSignUp = async () => {
    setError(null);
    setLoading(true);
    const { error } = await signUp.password({
      emailAddress: email,
      password: password,
    })
    if (error) {
      setError(JSON.stringify(errors, null, 2));
      haptics.error();
      return
    }
    if (!error) {
      setPendingCode(true);
      haptics.success();
      setLoading(false);
      await signUp.verifications.sendEmailCode()

    }
  };

  const handleVerify = async () => {
    setError(null);
    setLoading(true);
    try {
      const attempt = await signUp.verifications.verifyEmailCode({
        code,
      });
      if (signUp.status === 'complete') {
        await signUp.finalize({
          // Redirect the user to the home page after signing up
          navigate: ({ session, decorateUrl }) => {
            if (session?.currentTask) {
              console.log(session?.currentTask)
              return
            }
          },
        })
        haptics.success();
        router.push('/(onboarding)/step-1');
      } else {
        setError('Verification incomplete. Please try again.');
      }
    } catch (e) {
      const err = e as { errors?: { message?: string }[]; message?: string };
      setError(err.errors?.[0]?.message ?? err.message ?? 'Could not verify code.');
      haptics.error();
    } finally {
      setLoading(false);
      router.push('/(onboarding)/step-1');
    }
  };

  const disabled = !email || !password;
  return (
    <SafeScreen keyboardAvoiding>
      <ScreenHeader title={pendingCode ? 'Check your email' : 'Create account'} />

      <ScrollView
        contentContainerStyle={{ paddingTop: 16, paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {!pendingCode ? (
          <>
            <Text variant="title1" style={{ marginBottom: 8 }}>
              Welcome to Soullink
            </Text>
            <Text variant="body" tone="secondary" style={{ marginBottom: 28 }}>
              Your profile is private until you're verified.
            </Text>

            <View style={{ gap: 16 }}>
              <Input
                label="Email"
                value={email}
                onChangeText={setEmail}
                placeholder="you@example.com"
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
                textContentType="emailAddress"
              />
              <Input
                label="Password"
                value={password}
                onChangeText={setPassword}
                placeholder="At least 8 characters"
                secureTextEntry
                autoComplete="password-new"
                textContentType="newPassword"
                hint="Use a mix of letters, numbers, and symbols."
              />
              <Pressable
                style={styles.checkboxRow}
                onPress={() => setAgeOk((v) => !v)}
                accessibilityRole="checkbox"
                accessibilityState={{ checked: ageOk }}
              >
                <View
                  style={[
                    styles.checkbox,
                    {
                      borderColor: theme.colors.borderStrong,
                      backgroundColor: ageOk
                        ? theme.colors.text
                        : 'transparent',
                    },
                  ]}
                >
                  {ageOk ? (
                    <Ionicons
                      name="checkmark"
                      size={14}
                      color={theme.colors.background}
                    />
                  ) : null}
                </View>
                <Text variant="body" tone="secondary" style={{ flex: 1 }}>
                  I'm 18 or older and agree to Soullink's community rules.
                </Text>
              </Pressable>
            </View>

            {error ? (
              <Text variant="caption" tone="error" style={{ marginTop: 16 }}>
                {error}
              </Text>
            ) : null}

            <View style={{ marginTop: 28 }}>
              <Button
                label="Continue"
                onPress={handleSignUp}
                loading={loading}
                disabled={disabled}
                fullWidth
              />
            </View>

            <Pressable
              onPress={() => router.replace('/(auth)/sign-in')}
              style={{ marginTop: 20, alignItems: 'center' }}
            >
              <Text variant="body" tone="secondary">
                Already have an account?{' '}
                <Text variant="bodyMedium" tone="accent">
                  Sign in
                </Text>
              </Text>
            </Pressable>
          </>
        ) : (
          <>
            <Text variant="title1" style={{ marginBottom: 8 }}>
              Enter the code
            </Text>
            <Text variant="body" tone="secondary" style={{ marginBottom: 28 }}>
              We emailed a 6-digit code to {email}.
            </Text>

            <Input
              label="Verification code"
              value={code}
              onChangeText={setCode}
              placeholder="123456"
              keyboardType="number-pad"
              maxLength={6}
              autoFocus
            />

            {error ? (
              <Text variant="caption" tone="error" style={{ marginTop: 16 }}>
                {error}
              </Text>
            ) : null}

            <View style={{ marginTop: 28 }}>
              <Button
                label="Verify & continue"
                onPress={handleVerify}
                loading={loading}
                disabled={code.length < 6}
                fullWidth
              />
            </View>
          </>
        )}
      </ScrollView>
    </SafeScreen>
  );
}

const styles = StyleSheet.create({
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 4,
  },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
