// app/index.tsx — Entry point that routes the user to the right place.
//
// Routing matrix:
//   Not signed in                            → /welcome
//   Signed in, no profile yet                → /(onboarding)/step-1
//   Signed in, profile exists, not verified  → /(verification)/selfie
//   Signed in, verified                      → /(tabs)
//
// Using a small auth gate here (rather than middleware) keeps the
// navigation predictable and lets us show a minimal loader while Clerk
// hydrates and the profile is fetched.

import { useAuth } from '@clerk/expo';
import { Redirect } from 'expo-router';
import React from 'react';
import { ActivityIndicator, View } from 'react-native';

import { useTheme } from '@/src/contexts/ThemeContext';
import { useMyProfile } from '@/src/hooks/useApi';

export default function Index() {
  const { isLoaded, isSignedIn } = useAuth();
  const { theme } = useTheme();

  const { data: profile, isLoading: profileLoading, isError } = useMyProfile();

  if (!isLoaded || (isSignedIn && profileLoading)) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: theme.colors.background,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <ActivityIndicator color={theme.colors.text} />
      </View>
    );
  }

  if (!isSignedIn) {
    return <Redirect href="/welcome" />;
  }

  // Signed in.
  if (!profile && !isError) {
    return <Redirect href="/(onboarding)/step-1" />;
  }

  if (profile && profile.verificationStatus !== 'approved') {
    return <Redirect href="/(verification)/selfie" />;
  }

  return <Redirect href="/(tabs)" />;
}
