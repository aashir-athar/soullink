// src/hooks/useAuthBridge.ts — wires Clerk's session token into our API client.
//
// Mounting this once in the root layout ensures every axios request ships
// a fresh JWT without React context gymnastics.

import { registerTokenGetter } from '@/src/services/api';
import { disconnectSocket } from '@/src/services/socket';
import { useAuth } from '@clerk/expo';
import { useEffect } from 'react';

export function useAuthBridge(): void {
  const { isSignedIn, getToken } = useAuth();

  useEffect(() => {
    registerTokenGetter(async () => {
      try {
        return await getToken();
      } catch {
        return null;
      }
    });
  }, [getToken]);

  useEffect(() => {
    if (!isSignedIn) {
      // Tear down socket when signed out so it doesn't linger with stale auth.
      disconnectSocket();
    }
  }, [isSignedIn]);
}
