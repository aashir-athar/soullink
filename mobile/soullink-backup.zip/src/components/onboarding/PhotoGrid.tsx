// src/components/onboarding/PhotoGrid.tsx — 5-slot photo picker grid.
//
// The slots communicate scarcity ("maximum 5") visually and make it
// obvious which is the main photo. Long-press on any slot opens actions
// (set main / remove). This keeps the primary UI simple.

import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import React, { memo, useCallback, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  View,
} from 'react-native';

import { BottomSheet } from '@/src/components/ui/BottomSheet';
import { Button } from '@/src/components/ui/Button';
import { Text } from '@/src/components/ui/Text';
import { useTheme } from '@/src/contexts/ThemeContext';
import { useUploadPhoto } from '@/src/hooks/useApi';
import * as api from '@/src/services/endPoints';
import type { Photo } from '@/src/types';
import { haptics } from '@/src/utils/haptics';

interface Props {
  photos: Photo[];
  onChange: (photos: Photo[]) => void;
  maxPhotos?: number;
}

function PhotoGridBase({ photos, onChange, maxPhotos = 5 }: Props) {
  const { theme } = useTheme();
  const { mutateAsync: upload, isPending: uploading } = useUploadPhoto();
  const [deletingIndex, setDeletingIndex] = useState<number | null>(null);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);

  const pickImage = useCallback(async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) return;
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.85,
      allowsEditing: true,
      aspect: [3, 4],
    });
    if (result.canceled || !result.assets[0]) return;

    try {
      const uploaded = await upload(result.assets[0].uri);
      const next: Photo[] = [
        ...photos,
        {
          ...uploaded,
          isMain: photos.length === 0,
          order: photos.length,
        },
      ];
      onChange(next);
      haptics.success();
    } catch {
      haptics.error();
    }
  }, [upload, photos, onChange]);

  const setAsMain = useCallback(
    (index: number) => {
      const next = photos.map((p, i) => ({ ...p, isMain: i === index }));
      onChange(next);
      setSelectedIdx(null);
    },
    [photos, onChange]
  );

  const remove = useCallback(
    async (index: number) => {
      const photo = photos[index];
      if (!photo) return;
      setDeletingIndex(index);
      try {
        await api.deletePhoto(photo.cloudinaryPublicId);
      } catch {
        /* ignore — still remove locally */
      }
      const next = photos
        .filter((_, i) => i !== index)
        .map((p, i) => ({ ...p, order: i }));
      // Ensure a main photo remains
      if (!next.some((p) => p.isMain) && next.length > 0) next[0]!.isMain = true;
      onChange(next);
      setDeletingIndex(null);
      setSelectedIdx(null);
    },
    [photos, onChange]
  );

  const slots = Array.from({ length: maxPhotos }, (_, i) => photos[i] ?? null);

  return (
    <>
      <View style={styles.grid}>
        {slots.map((photo, idx) => {
          if (!photo) {
            const isNextSlot = idx === photos.length;
            return (
              <Pressable
                key={`slot-${idx}`}
                onPress={isNextSlot ? pickImage : undefined}
                disabled={!isNextSlot || uploading}
                style={[
                  styles.cell,
                  {
                    backgroundColor: theme.colors.surfaceMuted,
                    borderRadius: theme.radii.lg,
                    borderColor: isNextSlot
                      ? theme.colors.borderStrong
                      : theme.colors.borderSubtle,
                    borderWidth: isNextSlot ? 1.5 : StyleSheet.hairlineWidth,
                    borderStyle: isNextSlot ? 'dashed' : 'solid',
                    opacity: isNextSlot ? 1 : 0.5,
                  },
                ]}
                accessibilityRole="button"
                accessibilityLabel={
                  isNextSlot ? 'Add photo' : 'Empty photo slot'
                }
              >
                {uploading && isNextSlot ? (
                  <ActivityIndicator color={theme.colors.text} />
                ) : (
                  <Ionicons
                    name="add"
                    size={28}
                    color={
                      isNextSlot
                        ? theme.colors.text
                        : theme.colors.textTertiary
                    }
                  />
                )}
              </Pressable>
            );
          }

          return (
            <Pressable
              key={photo.cloudinaryPublicId}
              onPress={() => {
                haptics.light();
                setSelectedIdx(idx);
              }}
              style={[
                styles.cell,
                {
                  borderRadius: theme.radii.lg,
                  overflow: 'hidden',
                },
              ]}
              accessibilityRole="button"
              accessibilityLabel={`Photo ${idx + 1}${photo.isMain ? ', main photo' : ''}`}
            >
              <Image
                source={{ uri: photo.cloudinaryUrl }}
                style={StyleSheet.absoluteFill}
                contentFit="cover"
                transition={150}
                cachePolicy="memory-disk"
              />
              {photo.isMain ? (
                <View
                  style={[
                    styles.mainBadge,
                    { backgroundColor: theme.colors.text },
                  ]}
                >
                  <Text variant="micro" color={theme.colors.background}>
                    MAIN
                  </Text>
                </View>
              ) : null}
              {deletingIndex === idx ? (
                <View style={[StyleSheet.absoluteFill, styles.loading]}>
                  <ActivityIndicator color="#fff" />
                </View>
              ) : null}
            </Pressable>
          );
        })}
      </View>

      <BottomSheet
        visible={selectedIdx !== null}
        onClose={() => setSelectedIdx(null)}
      >
        <View style={{ padding: 20, gap: 12 }}>
          <Text variant="title3" style={{ marginBottom: 8 }}>
            Photo options
          </Text>
          {selectedIdx !== null && photos[selectedIdx] && !photos[selectedIdx]!.isMain ? (
            <Button
              label="Set as main photo"
              variant="secondary"
              fullWidth
              onPress={() => setAsMain(selectedIdx)}
            />
          ) : null}
          <Button
            label="Remove photo"
            variant="destructive"
            fullWidth
            onPress={() => selectedIdx !== null && remove(selectedIdx)}
          />
          <Button
            label="Cancel"
            variant="ghost"
            fullWidth
            onPress={() => setSelectedIdx(null)}
          />
        </View>
      </BottomSheet>
    </>
  );
}

const styles = StyleSheet.create({
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  cell: {
    width: '31.5%',
    aspectRatio: 3 / 4,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  mainBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  loading: {
    backgroundColor: 'rgba(0,0,0,0.45)',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export const PhotoGrid = memo(PhotoGridBase);
