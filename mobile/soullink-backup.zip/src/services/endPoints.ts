// src/services/endpoints.ts — Thin wrappers around backend routes.
// These are consumed by React Query hooks; keeping them one layer above axios
// makes the hooks clean and the services independently testable.

import type {
  AppNotification,
  DailyLimits,
  DiscoverFilters,
  DiscoverResponse,
  FullUser,
  Match,
  MatchingMode,
  Message,
  MessagesResponse,
  OnboardingDraft,
  Photo,
  SwipeResponse,
  UserProfile,
} from '@/src/types';
import { api } from './api';

/* ─── Profile ─────────────────────────────────────────────────────────── */

export async function getMyProfile(): Promise<UserProfile | null> {
  try {
    const { data } = await api.get<UserProfile>('/api/profile/me');
    return data;
  } catch (e) {
    const err = e as { status?: number };
    if (err.status === 404) return null;
    throw e;
  }
}

export interface CreateProfilePayload
  extends Omit<OnboardingDraft, 'gender' | 'dateOfBirth'> {
  gender: 'male' | 'female';
  dateOfBirth: string;
  email?: string;
}

export async function createProfile(payload: CreateProfilePayload): Promise<UserProfile> {
  const { data } = await api.post<UserProfile>('/api/profile', payload);
  return data;
}

export async function updateProfile(
  patch: Partial<UserProfile>
): Promise<UserProfile> {
  const { data } = await api.patch<UserProfile>('/api/profile/me', patch);
  return data;
}

export async function deleteMyAccount(): Promise<void> {
  await api.delete('/api/profile/me');
}

/** Uploads a single image file (local URI) to the backend which forwards to
 *  Cloudinary. Returns the Cloudinary metadata to be saved on the profile. */
export async function uploadPhoto(
  localUri: string
): Promise<{ cloudinaryUrl: string; cloudinaryPublicId: string }> {
  const form = new FormData();
  const filename = localUri.split('/').pop() ?? `photo-${Date.now()}.jpg`;
  const ext = filename.split('.').pop()?.toLowerCase() ?? 'jpg';
  const mime = ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg';

  form.append('photo', {
    uri: localUri,
    name: filename,
    type: mime,
  } as unknown as Blob);

  const { data } = await api.post<{
    cloudinaryUrl: string;
    cloudinaryPublicId: string;
  }>('/api/profile/photos', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    transformRequest: (d) => d, // axios would try to JSON-stringify otherwise
  });
  return data;
}

export async function deletePhoto(publicId: string): Promise<void> {
  await api.delete(`/api/profile/photos/${encodeURIComponent(publicId)}`);
}

export async function submitVerification(selfieUrl: string): Promise<void> {
  await api.post('/api/profile/verify', { selfieUrl });
}

/* ─── Discovery ───────────────────────────────────────────────────────── */

export async function getDiscoverFeed(
  mode: MatchingMode,
  filters: DiscoverFilters,
  page = 1
): Promise<DiscoverResponse> {
  const { data } = await api.get<DiscoverResponse>(`/api/discover/${mode}`, {
    params: {
      page,
      ageMin: filters.ageMin,
      ageMax: filters.ageMax,
      sameCity: filters.sameCity ? 'true' : 'false',
    },
  });
  return data;
}

export async function swipe(
  targetUserId: string,
  action: 'like' | 'pass',
  mode: MatchingMode,
  compliment?: string
): Promise<SwipeResponse> {
  const { data } = await api.post<SwipeResponse>('/api/discover/swipe', {
    targetUserId,
    action,
    mode,
    compliment,
  });
  return data;
}

export async function sendCompliment(
  targetUserId: string,
  mode: MatchingMode,
  text: string
): Promise<void> {
  await api.post('/api/discover/compliment', { targetUserId, mode, text });
}

export async function getDailyLimits(): Promise<DailyLimits> {
  const { data } = await api.get<DailyLimits>('/api/discover/limits');
  return data;
}

/* ─── Matches ─────────────────────────────────────────────────────────── */

export async function getMatches(): Promise<Match[]> {
  const { data } = await api.get<Match[]>('/api/matches');
  return data;
}

export async function unmatch(matchId: string): Promise<void> {
  await api.delete(`/api/matches/${matchId}`);
}

/* ─── Messages ────────────────────────────────────────────────────────── */

export async function getMessages(
  matchId: string,
  page = 1
): Promise<MessagesResponse> {
  const { data } = await api.get<MessagesResponse>(`/api/messages/${matchId}`, {
    params: { page },
  });
  return data;
}

export async function sendMessage(
  matchId: string,
  content: string
): Promise<Message> {
  const { data } = await api.post<Message>(`/api/messages/${matchId}`, {
    content,
  });
  return data;
}

export async function markMessagesRead(matchId: string): Promise<void> {
  await api.patch(`/api/messages/${matchId}/read`);
}

/* ─── Users ───────────────────────────────────────────────────────────── */

export async function getUserById(userId: string): Promise<FullUser> {
  const { data } = await api.get<FullUser>(`/api/users/${userId}`);
  return data;
}

/* ─── Safety ──────────────────────────────────────────────────────────── */

export async function reportUser(
  reportedUserId: string,
  reason: string,
  details?: string
): Promise<void> {
  await api.post('/api/safety/report', { reportedUserId, reason, details });
}

export async function blockUser(blockedUserId: string): Promise<void> {
  await api.post('/api/safety/block', { blockedUserId });
}

export async function unblockUser(blockedUserId: string): Promise<void> {
  await api.delete(`/api/safety/block/${blockedUserId}`);
}

export async function getBlockedUsers(): Promise<string[]> {
  const { data } = await api.get<string[]>('/api/safety/blocked');
  return data;
}

/* ─── Notifications ───────────────────────────────────────────────────── */

export async function getNotifications(): Promise<AppNotification[]> {
  const { data } = await api.get<AppNotification[]>('/api/notifications');
  return data;
}

export async function markAllNotificationsRead(): Promise<void> {
  await api.patch('/api/notifications/read-all');
}

export async function registerPushToken(
  token: string,
  platform: 'ios' | 'android'
): Promise<void> {
  await api.post('/api/notifications/push-token', { token, platform });
}

/* ─── Type re-exports used directly by hooks ──────────────────────────── */
export type { Photo };
