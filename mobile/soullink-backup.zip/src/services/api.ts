// src/services/api.ts — Axios client for the Soullink backend.
//
// The instance attaches a fresh Clerk JWT on every request via the
// `setTokenGetter` registration. This lets us keep the axios singleton
// pure (no React context) while still respecting Clerk's session.

import axios, { type AxiosInstance, type AxiosError } from 'axios';

const API_URL =
  process.env.EXPO_PUBLIC_API_URL ?? 'http://localhost:3000';

type TokenGetter = () => Promise<string | null>;

let tokenGetter: TokenGetter | null = null;

export const registerTokenGetter = (getter: TokenGetter) => {
  tokenGetter = getter;
};

export const api: AxiosInstance = axios.create({
  baseURL: API_URL,
  timeout: 20_000,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use(async (config) => {
  if (tokenGetter) {
    try {
      const token = await tokenGetter();
      if (token) {
        config.headers.set('Authorization', `Bearer ${token}`);
      }
    } catch {
      /* proceed without — server will 401 and caller can re-auth */
    }
  }
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (error: AxiosError<{ message?: string }>) => {
    // Normalise error message so UI layer has a single shape to consume.
    const message =
      error.response?.data?.message ??
      error.message ??
      'Something went wrong. Please try again.';
    return Promise.reject(
      Object.assign(new Error(message), {
        status: error.response?.status,
        original: error,
      })
    );
  }
);

export const API_BASE_URL = API_URL;
